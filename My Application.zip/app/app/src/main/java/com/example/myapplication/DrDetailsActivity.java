package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.lang.annotation.Documented;
import java.util.ArrayList;
import java.util.HashMap;

public class DrDetailsActivity extends AppCompatActivity {

    private String[][] dr_details1 =
            {
                    {"Stomatolog : Marzena Medyk", "Miejsce przyjęć : Klinika Gdańsk", "Specjalizacja : Ortodoncja", "Nr tel : 123456789"}
            };

    private String[][] dr_details2 =
            {
                    {"Stomatolog : Rafał Tomaszewski", "Miejsce przyjęć : Klinika Gdynia", "Specjalizacja : Chirurgia", "Nr tel : 456789123"}
            };

    private String[][] dr_details3 =
            {
                    {"Stomatolog : Anna Wasilewska", "Miejsce przyjęć : Klinika Sopot", "Specjalizacja : Chirurgia szczękowa", "Nr tel : 789123456"}
            };

    private String[][] dr_details4 =
            {
                    {"Stomatolog : Tomasz Król", "Miejsce przyjęć : Klinika Szczecin", "Specjalizacja : Periodontologia", "Nr tel : 147258369"}
            };

    private String[][] dr_details5 =
            {
                    {"Stomatolog : Katarzyna Wenta", "Miejsce przyjęć : Klinika Kołobrzeg", "Specjalizacja : Endodoncja", "Nr tel : 963852741"}
            };
    TextView tv;
    Button btn;

    String [][] dr_details = {};
    ArrayList list;
    HashMap<String, String> item;
    SimpleAdapter sa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dr_details);

        tv = findViewById(R.id.textViewDDTitle);
        btn = findViewById(R.id.buttonPowrot);

        Intent it = getIntent();
        String title = it.getStringExtra("title");
        tv.setText(title);

        if(title.compareTo("drMarzena") == 0)
            dr_details = dr_details1;
        else
        if(title.compareTo("drRafal") == 0)
            dr_details = dr_details2;
        else
        if(title.compareTo("drAnna") == 0)
            dr_details = dr_details3;
        else
        if(title.compareTo("drTomasz") == 0)
            dr_details = dr_details4;
        else
            dr_details = dr_details5;


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DrDetailsActivity.this, FindDoctorActivity.class));
            }
        });

        list = new ArrayList();
        for(int i = 0; i < dr_details.length; i++){
            item = new HashMap<String, String>();
            item.put("line1", dr_details1[i][0]);
            item.put("line2", dr_details1[i][1]);
            item.put("line3", dr_details1[i][2]);
            item.put("line4", dr_details1[i][3]);
            item.put("line5", dr_details1[i][4]);
            list.add(item);
        }
    }
}
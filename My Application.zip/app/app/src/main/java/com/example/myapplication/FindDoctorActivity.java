package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class FindDoctorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_doctor);

        CardView exit = findViewById(R.id.cardPowrot);
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FindDoctorActivity.this, HomeActivity.class));
            }
        });

        CardView drMarzena = findViewById(R.id.cardDrMarzena);
        drMarzena.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(FindDoctorActivity.this, DrDetailsActivity.class);
                it.putExtra("title", "Dr Marzena Medyk");
                startActivity(it);
            }
        });

        CardView drRafal = findViewById(R.id.cardDrRafal);
        drRafal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(FindDoctorActivity.this, DrDetailsActivity.class);
                it.putExtra("title", "Dr Rafał Tomaszewski");
                startActivity(it);
            }
        });

        CardView drAnna = findViewById(R.id.cardDrAnna);
        drAnna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(FindDoctorActivity.this, DrDetailsActivity.class);
                it.putExtra("title", "Dr Anna Wasilewska");
                startActivity(it);
            }
        });

        CardView drTomasz = findViewById(R.id.cardDrTomasz);
        drTomasz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(FindDoctorActivity.this, DrDetailsActivity.class);
                it.putExtra("title", "Dr Tomasz Król");
                startActivity(it);
            }
        });

        CardView drKatarzyna = findViewById(R.id.cardDrKatarzyna);
        drKatarzyna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(FindDoctorActivity.this, DrDetailsActivity.class);
                it.putExtra("title", "Dr Katarzyna Wenta");
                startActivity(it);
            }
        });
    }
}